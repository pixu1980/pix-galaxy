/** @typedef {'kw' | 'str' | 'num' | 'com' | 'id' | 'op' | 'tag' | 'attr' | 'key' | 'var' | 'mac' | 'pp' | 'prop' | 'type' | 'mdh' | 'mde' | 'mds' | 'mdc' | 'mdl' | 'mdbq' | 'mdli' | 'mdhr' | 'mdimg'} PixHighlighterTokenType */
export type PixHighlighterTokenType = 'kw' | 'str' | 'num' | 'com' | 'id' | 'op' | 'tag' | 'attr' | 'key' | 'var' | 'mac' | 'pp' | 'prop' | 'type' | 'mdh' | 'mde' | 'mds' | 'mdc' | 'mdl' | 'mdbq' | 'mdli' | 'mdhr' | 'mdimg';
export type PixHighlighterToken = {
    type: PixHighlighterTokenType;
    start: number;
    end: number;
};
export type PixHighlighterLexer = (source: string) => PixHighlighterToken[];
/**
 * @typedef {object} PixHighlighterToken
 * @property {PixHighlighterTokenType} type
 * @property {number} start
 * @property {number} end
 */
/**
 * @callback PixHighlighterLexer
 * @param {string} source
 * @returns {PixHighlighterToken[]}
 */
/**
 * Browser-native syntax-highlighting custom element.
 */
export declare class PixHighlighter extends HTMLPreElement {
    /** @type {Set<PixHighlighter>} */
    static instances: Set<PixHighlighter>;
    /** @type {readonly PixHighlighterTokenType[]} */
    static KNOWN_TYPES: readonly PixHighlighterTokenType[];
    /** @returns {CSSStyleSheet | HTMLStyleElement | null} */
    static ensureComponentStyles(): CSSStyleSheet | HTMLStyleElement | null;
    /** @returns {boolean} */
    static registerCustomElement(): boolean;
    /** @returns {boolean} */
    static supportsHighlights(): boolean;
    /** @returns {string | null} */
    static getSavedTheme(): string | null;
    /** @returns {string} */
    static getCurrentTheme(): string;
    /** @returns {string} */
    static getInitialTheme(): string;
    /**
     * @param {string} theme
     * @param {{ persist?: boolean; syncInstances?: boolean }} [options]
     * @returns {string}
     */
    static applyTheme(theme: string, options?: {
        persist?: boolean;
        syncInstances?: boolean;
    }): string;
    /** @returns {void} */
    static clearManagedHighlights(): void;
    /**
     * @param {HTMLPreElement} element
     * @returns {PixHighlighter | null}
     */
    static enhanceElement(element: HTMLPreElement): PixHighlighter | null;
    /**
     * @param {Document | Element} [root=document]
     * @returns {PixHighlighter[]}
     */
    static enhanceAll(root?: Document | Element): PixHighlighter[];
    /** @returns {void} */
    connectedCallback(): void;
    /** @returns {void} */
    disconnectedCallback(): void;
}
/**
 * @type {ReadonlyArray<{value: string, label: string}>}
 */
export declare const PIX_HIGHLIGHTER_THEME_OPTIONS: ReadonlyArray<{
    value: string;
    label: string;
}>;
/**
 * Enhance all matching `pre[is="pix-highlighter"]` blocks under the provided root.
 * @param {Document | Element} [root=document]
 * @returns {PixHighlighter[]}
 */
export declare function enhancePixHighlighters(root?: Document | Element): PixHighlighter[];
/**
 * @param {string | null | undefined} [value]
 * @returns {string}
 */
export declare function normalizeLang(value?: string | null | undefined): string;
/** @type {PixHighlighterLexer} */
export declare const lexBash: PixHighlighterLexer;
/** @type {PixHighlighterLexer} */
export declare const lexC: PixHighlighterLexer;
/** @type {PixHighlighterLexer} */
export declare const lexCPP: PixHighlighterLexer;
/** @type {PixHighlighterLexer} */
export declare const lexCSharp: PixHighlighterLexer;
/** @type {PixHighlighterLexer} */
export declare const lexCSS: PixHighlighterLexer;
/** @type {PixHighlighterLexer} */
export declare const lexGo: PixHighlighterLexer;
/** @type {PixHighlighterLexer} */
export declare const lexHTML: PixHighlighterLexer;
/** @type {PixHighlighterLexer} */
export declare const lexJS: PixHighlighterLexer;
/** @type {PixHighlighterLexer} */
export declare const lexJSON: PixHighlighterLexer;
/** @type {PixHighlighterLexer} */
export declare const lexMarkdown: PixHighlighterLexer;
/** @type {PixHighlighterLexer} */
export declare const lexPHP: PixHighlighterLexer;
/** @type {PixHighlighterLexer} */
export declare const lexPython: PixHighlighterLexer;
/** @type {PixHighlighterLexer} */
export declare const lexRust: PixHighlighterLexer;
/** @type {PixHighlighterLexer} */
export declare const lexTS: PixHighlighterLexer;
/** @type {PixHighlighterLexer} */
export declare const lexYAML: PixHighlighterLexer;
