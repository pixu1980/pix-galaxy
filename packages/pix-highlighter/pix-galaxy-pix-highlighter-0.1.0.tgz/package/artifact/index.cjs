var O=Object.defineProperty;var fe=Object.getOwnPropertyDescriptor;var xe=Object.getOwnPropertyNames;var ke=Object.prototype.hasOwnProperty;var ye=(i,s,r)=>s in i?O(i,s,{enumerable:!0,configurable:!0,writable:!0,value:r}):i[s]=r;var be=(i,s)=>{for(var r in s)O(i,r,{get:s[r],enumerable:!0})},_e=(i,s,r,h)=>{if(s&&typeof s=="object"||typeof s=="function")for(let e of xe(s))!ke.call(i,e)&&e!==r&&O(i,e,{get:()=>s[e],enumerable:!(h=fe(s,e))||h.enumerable});return i};var we=i=>_e(O({},"__esModule",{value:!0}),i);var P=(i,s,r)=>ye(i,typeof s!="symbol"?s+"":s,r);var Ue={};be(Ue,{PIX_HIGHLIGHTER_THEME_OPTIONS:()=>Y,PixHighlighter:()=>V,enhancePixHighlighters:()=>me,lexBash:()=>E,lexC:()=>j,lexCPP:()=>I,lexCSS:()=>B,lexCSharp:()=>z,lexGo:()=>R,lexHTML:()=>W,lexJS:()=>S,lexJSON:()=>q,lexMarkdown:()=>A,lexPHP:()=>F,lexPython:()=>K,lexRust:()=>$,lexTS:()=>D,lexYAML:()=>M,normalizeLang:()=>H});module.exports=we(Ue);var Q=`/** PixHighlighter - pix-highlighter component styles. */
@layer pix-galaxy {
  @layer pix-highlighter {
    ::highlight(pix-kw),
    pre[is='pix-highlighter'] [data-token='kw'] {
      color: var(--pix-highlighter--kw);
    }

    ::highlight(pix-str),
    pre[is='pix-highlighter'] [data-token='str'] {
      color: var(--pix-highlighter--str);
    }

    ::highlight(pix-num),
    pre[is='pix-highlighter'] [data-token='num'] {
      color: var(--pix-highlighter--num);
    }

    ::highlight(pix-com),
    pre[is='pix-highlighter'] [data-token='com'] {
      color: var(--pix-highlighter--com);
    }

    ::highlight(pix-id),
    pre[is='pix-highlighter'] [data-token='id'] {
      color: var(--pix-highlighter--id);
    }

    ::highlight(pix-op),
    pre[is='pix-highlighter'] [data-token='op'] {
      color: var(--pix-highlighter--op);
    }

    ::highlight(pix-tag),
    pre[is='pix-highlighter'] [data-token='tag'] {
      color: var(--pix-highlighter--tag);
    }

    ::highlight(pix-attr),
    pre[is='pix-highlighter'] [data-token='attr'] {
      color: var(--pix-highlighter--attr);
    }

    ::highlight(pix-key),
    pre[is='pix-highlighter'] [data-token='key'] {
      color: var(--pix-highlighter--key);
    }

    ::highlight(pix-var),
    pre[is='pix-highlighter'] [data-token='var'] {
      color: var(--pix-highlighter--var);
    }

    ::highlight(pix-mac),
    pre[is='pix-highlighter'] [data-token='mac'] {
      color: var(--pix-highlighter--mac);
    }

    ::highlight(pix-pp),
    pre[is='pix-highlighter'] [data-token='pp'] {
      color: var(--pix-highlighter--pp);
    }

    ::highlight(pix-prop),
    pre[is='pix-highlighter'] [data-token='prop'] {
      color: var(--pix-highlighter--prop);
    }

    ::highlight(pix-type),
    pre[is='pix-highlighter'] [data-token='type'] {
      color: var(--pix-highlighter--type);
    }

    ::highlight(pix-mdh),
    pre[is='pix-highlighter'] [data-token='mdh'] {
      color: var(--pix-highlighter--mdh);
    }

    ::highlight(pix-mde),
    pre[is='pix-highlighter'] [data-token='mde'] {
      color: var(--pix-highlighter--mde);
    }

    ::highlight(pix-mds),
    pre[is='pix-highlighter'] [data-token='mds'] {
      color: var(--pix-highlighter--mds);
    }

    ::highlight(pix-mdc),
    pre[is='pix-highlighter'] [data-token='mdc'] {
      color: var(--pix-highlighter--mdc);
    }

    ::highlight(pix-mdl),
    pre[is='pix-highlighter'] [data-token='mdl'] {
      color: var(--pix-highlighter--mdl);
    }

    ::highlight(pix-mdbq),
    pre[is='pix-highlighter'] [data-token='mdbq'] {
      color: var(--pix-highlighter--mdbq);
    }

    ::highlight(pix-mdli),
    pre[is='pix-highlighter'] [data-token='mdli'] {
      color: var(--pix-highlighter--mdli);
    }

    ::highlight(pix-mdhr),
    pre[is='pix-highlighter'] [data-token='mdhr'] {
      color: var(--pix-highlighter--mdhr);
    }

    ::highlight(pix-mdimg),
    pre[is='pix-highlighter'] [data-token='mdimg'] {
      color: var(--pix-highlighter--mdimg);
    }
  }
}
`;var ee=`/**
 * FILE: _cyberpunk.css
 * USAGE: Stylesheet for packages/pix-highlighter/src/components/PixHighlighter/styles/themes/_cyberpunk.css.
 * SCOPE: File-local selectors and pix-galaxy design tokens.
 */
@layer pix-galaxy {
  @layer pix-highlighter {
    @layer themes {
      :root[data-pix-highlighter-theme='cyberpunk'] pre[is='pix-highlighter'] {
        --pix-highlighter--bg: light-dark(#fff4fd, #090412);
        --pix-highlighter--fg: light-dark(#2f1140, #f9f7ff);
        --pix-highlighter--kw: light-dark(#c026d3, #ff4fd8);
        --pix-highlighter--str: light-dark(#ca8a04, #ffe45e);
        --pix-highlighter--num: light-dark(#0891b2, #62f3ff);
        --pix-highlighter--com: light-dark(#8b7aa8, #8b7aa8);
        --pix-highlighter--id: light-dark(#0f9f7f, #7ef7c9);
        --pix-highlighter--fn: light-dark(#00a896, #00f5d4);
        --pix-highlighter--op: light-dark(#ea580c, #ff8b39);
        --pix-highlighter--tag: light-dark(#db2777, #ff4fd8);
        --pix-highlighter--attr: light-dark(#0284c7, #4cc9f0);
        --pix-highlighter--key: light-dark(#0891b2, #62f3ff);
        --pix-highlighter--var: light-dark(#0f9f7f, #7ef7c9);
        --pix-highlighter--mac: light-dark(#db2777, #ff6ad5);
        --pix-highlighter--pp: light-dark(#ea580c, #ff9f1c);
        --pix-highlighter--prop: light-dark(#7c3aed, #9d7dff);
        --pix-highlighter--type: light-dark(#0284c7, #4cc9f0);
        --pix-highlighter--mdh: light-dark(#c026d3, #ff4fd8);
        --pix-highlighter--mde: light-dark(#ea580c, #ff8b39);
        --pix-highlighter--mds: light-dark(#ca8a04, #ffe45e);
        --pix-highlighter--mdc: light-dark(#0891b2, #62f3ff);
        --pix-highlighter--mdl: light-dark(#0f9f7f, #7ef7c9);
        --pix-highlighter--mdbq: light-dark(#8b7aa8, #a59ac7);
        --pix-highlighter--mdli: light-dark(#ea580c, #ff9f1c);
        --pix-highlighter--mdhr: light-dark(#eadcf8, #453363);
        --pix-highlighter--mdimg: light-dark(#0284c7, #4cc9f0);
        --pix-highlighter--tab-size: 2;
        --pix-highlighter--line-height: 1.55;
        --pix-highlighter--text-shadow: light-dark(none, 0 0 1.125rem rgba(255, 79, 216, 0.18));
      }
    }
  }
}
`;var te=`/**
 * FILE: _darcula.css
 * USAGE: Stylesheet for packages/pix-highlighter/src/components/PixHighlighter/styles/themes/_darcula.css.
 * SCOPE: File-local selectors and pix-galaxy design tokens.
 */
@layer pix-galaxy {
  @layer pix-highlighter {
    @layer themes {
      :root[data-pix-highlighter-theme='darcula'] pre[is='pix-highlighter'] {
        --pix-highlighter--bg: light-dark(#f4f5f7, #2b2b2b);
        --pix-highlighter--fg: light-dark(#2f3136, #a9b7c6);
        --pix-highlighter--kw: light-dark(#c05621, #cc7832);
        --pix-highlighter--str: light-dark(#4d7c0f, #6a8759);
        --pix-highlighter--num: light-dark(#2563eb, #6897bb);
        --pix-highlighter--com: light-dark(#808080, #808080);
        --pix-highlighter--id: light-dark(#7c3aed, #9876aa);
        --pix-highlighter--fn: light-dark(#0284c7, #56a8f5);
        --pix-highlighter--op: light-dark(#2f3136, #a9b7c6);
        --pix-highlighter--tag: light-dark(#b45309, #e8bf6a);
        --pix-highlighter--attr: light-dark(#57534e, #bababa);
        --pix-highlighter--key: light-dark(#7c3aed, #9876aa);
        --pix-highlighter--var: light-dark(#7c3aed, #9876aa);
        --pix-highlighter--mac: light-dark(#7c6f00, #bbb529);
        --pix-highlighter--pp: light-dark(#b45309, #ffc66d);
        --pix-highlighter--prop: light-dark(#b45309, #ffc66d);
        --pix-highlighter--type: light-dark(#2563eb, #a9b7c6);
        --pix-highlighter--mdh: light-dark(#b45309, #ffc66d);
        --pix-highlighter--mde: light-dark(#c05621, #cc7832);
        --pix-highlighter--mds: light-dark(#2f3136, #e8bf6a);
        --pix-highlighter--mdc: light-dark(#4d7c0f, #6a8759);
        --pix-highlighter--mdl: light-dark(#2563eb, #6897bb);
        --pix-highlighter--mdbq: light-dark(#808080, #808080);
        --pix-highlighter--mdli: light-dark(#7c3aed, #9876aa);
        --pix-highlighter--mdhr: light-dark(#d4d4d8, #5c6370);
        --pix-highlighter--mdimg: light-dark(#7c6f00, #bbb529);
        --pix-highlighter--tab-size: 2;
        --pix-highlighter--line-height: 1.55;
        --pix-highlighter--text-shadow: none;
      }
    }
  }
}
`;var ie=`/**
 * FILE: _default.css
 * USAGE: Stylesheet for packages/pix-highlighter/src/components/PixHighlighter/styles/themes/_default.css.
 * SCOPE: File-local selectors and pix-galaxy design tokens.
 */
@layer pix-galaxy {
  @layer pix-highlighter {
    @layer themes {
      :root:not([data-pix-highlighter-theme]) pre[is='pix-highlighter'],
      :root[data-pix-highlighter-theme='default'] pre[is='pix-highlighter'] {
        --pix-highlighter--bg: light-dark(#f5f7fb, #0b0d10);
        --pix-highlighter--fg: light-dark(#182131, #e6e6e6);
        --pix-highlighter--kw: light-dark(#6d28d9, #c792ea);
        --pix-highlighter--str: light-dark(#a45a00, #ecc48d);
        --pix-highlighter--num: light-dark(#c05621, #f78c6c);
        --pix-highlighter--com: light-dark(#66758a, #697098);
        --pix-highlighter--id: light-dark(#2563eb, #82aaff);
        --pix-highlighter--fn: light-dark(#0f766e, #80cbc4);
        --pix-highlighter--op: light-dark(#3f7a14, #c3e88d);
        --pix-highlighter--tag: light-dark(#0f766e, #5ad4e6);
        --pix-highlighter--attr: light-dark(#b45309, #f2ae49);
        --pix-highlighter--key: light-dark(#6d28d9, #ffcc66);
        --pix-highlighter--var: light-dark(#2563eb, #82aaff);
        --pix-highlighter--mac: light-dark(#be185d, #ff9dd9);
        --pix-highlighter--pp: light-dark(#66758a, #8bd5ff);
        --pix-highlighter--prop: light-dark(#2563eb, #9cdcfe);
        --pix-highlighter--type: light-dark(#0f766e, #7fd5a3);
        --pix-highlighter--mdh: light-dark(#0f766e, #5ad4e6);
        --pix-highlighter--mde: light-dark(#6d28d9, #f2ae49);
        --pix-highlighter--mds: light-dark(#182131, #ffd166);
        --pix-highlighter--mdc: light-dark(#3f7a14, #c3e88d);
        --pix-highlighter--mdl: light-dark(#2563eb, #80cbc4);
        --pix-highlighter--mdbq: light-dark(#66758a, #a0a7bd);
        --pix-highlighter--mdli: light-dark(#2563eb, #b3e5fc);
        --pix-highlighter--mdhr: light-dark(#cbd5e1, #6c7a89);
        --pix-highlighter--mdimg: light-dark(#be185d, #90caf9);
        --pix-highlighter--tab-size: 2;
        --pix-highlighter--line-height: 1.5;
        --pix-highlighter--text-shadow: none;
      }
    }
  }
}
`;var he=`/**
 * FILE: _prettylights.css
 * USAGE: Stylesheet for packages/pix-highlighter/src/components/PixHighlighter/styles/themes/_prettylights.css.
 * SCOPE: File-local selectors and pix-galaxy design tokens.
 */
@layer pix-galaxy {
  @layer pix-highlighter {
    @layer themes {
      :root[data-pix-highlighter-theme='prettylights'] pre[is='pix-highlighter'] {
        --pix-highlighter--bg: light-dark(#f6f8fa, #151b23);
        --pix-highlighter--fg: light-dark(#1f2328, #f0f6fc);
        --pix-highlighter--kw: light-dark(#cf222e, #ff7b72);
        --pix-highlighter--str: light-dark(#0a3069, #a5d6ff);
        --pix-highlighter--num: light-dark(#1f2328, #f0f6fc);
        --pix-highlighter--com: light-dark(#59636e, #9198a1);
        --pix-highlighter--id: light-dark(#0969da, #79c0ff);
        --pix-highlighter--fn: light-dark(#8250df, #79c0ff);
        --pix-highlighter--op: light-dark(#0550ae, #79c0ff);
        --pix-highlighter--tag: light-dark(#0550ae, #7ee787);
        --pix-highlighter--attr: light-dark(#0550ae, #79c0ff);
        --pix-highlighter--key: light-dark(#0550ae, #7ee787);
        --pix-highlighter--var: light-dark(#0969da, #79c0ff);
        --pix-highlighter--mac: light-dark(#6639ba, #d2a8ff);
        --pix-highlighter--pp: light-dark(#59636e, #9198a1);
        --pix-highlighter--prop: light-dark(#0550ae, #7ee787);
        --pix-highlighter--type: light-dark(#6639ba, #d2a8ff);
        --pix-highlighter--mdh: light-dark(#0550ae, #1f6feb);
        --pix-highlighter--mde: light-dark(#6639ba, #d2a8ff);
        --pix-highlighter--mds: light-dark(#1f2328, #f0f6fc);
        --pix-highlighter--mdc: light-dark(#116329, #7ee787);
        --pix-highlighter--mdl: light-dark(#0a3069, #a5d6ff);
        --pix-highlighter--mdbq: light-dark(#59636e, #9198a1);
        --pix-highlighter--mdli: light-dark(#953800, #ffa657);
        --pix-highlighter--mdhr: light-dark(#59636e, #9198a1);
        --pix-highlighter--mdimg: light-dark(#953800, #ffa657);
        --pix-highlighter--tab-size: 2;
        --pix-highlighter--line-height: 1.6;
        --pix-highlighter--text-shadow: none;
      }
    }
  }
}
`;var re=`/**
 * FILE: _prism.css
 * USAGE: Stylesheet for packages/pix-highlighter/src/components/PixHighlighter/styles/themes/_prism.css.
 * SCOPE: File-local selectors and pix-galaxy design tokens.
 */
@layer pix-galaxy {
  @layer pix-highlighter {
    @layer themes {
      :root[data-pix-highlighter-theme='prism'] pre[is='pix-highlighter'] {
        --pix-highlighter--bg: light-dark(#f5f2f0, #16181d);
        --pix-highlighter--fg: light-dark(#111111, #f3f4f6);
        --pix-highlighter--kw: light-dark(#0077aa, #7dd3fc);
        --pix-highlighter--str: light-dark(#669900, #a3e635);
        --pix-highlighter--num: light-dark(#990055, #f472b6);
        --pix-highlighter--com: light-dark(#708090, #94a3b8);
        --pix-highlighter--id: light-dark(#0f766e, #67e8f9);
        --pix-highlighter--fn: light-dark(#dd4a68, #fb7185);
        --pix-highlighter--op: light-dark(#9a6e3a, #fde68a);
        --pix-highlighter--tag: light-dark(#990055, #f472b6);
        --pix-highlighter--attr: light-dark(#669900, #a3e635);
        --pix-highlighter--key: light-dark(#990055, #c084fc);
        --pix-highlighter--var: light-dark(#0f766e, #67e8f9);
        --pix-highlighter--mac: light-dark(#dd4a68, #fb7185);
        --pix-highlighter--pp: light-dark(#708090, #94a3b8);
        --pix-highlighter--prop: light-dark(#0f766e, #67e8f9);
        --pix-highlighter--type: light-dark(#dd4a68, #fb7185);
        --pix-highlighter--mdh: light-dark(#0077aa, #7dd3fc);
        --pix-highlighter--mde: light-dark(#dd4a68, #fb7185);
        --pix-highlighter--mds: light-dark(#111111, #f3f4f6);
        --pix-highlighter--mdc: light-dark(#669900, #a3e635);
        --pix-highlighter--mdl: light-dark(#0077aa, #7dd3fc);
        --pix-highlighter--mdbq: light-dark(#708090, #94a3b8);
        --pix-highlighter--mdli: light-dark(#990055, #c084fc);
        --pix-highlighter--mdhr: light-dark(#999999, #475569);
        --pix-highlighter--mdimg: light-dark(#ee9900, #fbbf24);
        --pix-highlighter--tab-size: 2;
        --pix-highlighter--font-family: Consolas, Monaco, 'Andale Mono', 'Ubuntu Mono', monospace;
        --pix-highlighter--line-height: 1.5;
        --pix-highlighter--text-shadow: light-dark(0 1px white, none);
      }
    }
  }
}
`;var ne=`/**
 * FILE: _monokai.css
 * USAGE: Stylesheet for packages/pix-highlighter/src/components/PixHighlighter/styles/themes/_monokai.css.
 * SCOPE: File-local selectors and pix-galaxy design tokens.
 */
@layer pix-galaxy {
  @layer pix-highlighter {
    @layer themes {
      :root[data-pix-highlighter-theme='monokai'] pre[is='pix-highlighter'] {
        --pix-highlighter--bg: light-dark(#f5f4ed, #272822);
        --pix-highlighter--fg: light-dark(#2c2c2c, #f8f8f2);
        --pix-highlighter--kw: light-dark(#c2245b, #f92672);
        --pix-highlighter--str: light-dark(#8a843f, #e6db74);
        --pix-highlighter--num: light-dark(#7d2ed8, #ae81ff);
        --pix-highlighter--com: light-dark(#7a7866, #88846f);
        --pix-highlighter--id: light-dark(#2c2c2c, #f8f8f2);
        --pix-highlighter--op: light-dark(#c2245b, #f92672);
        --pix-highlighter--tag: light-dark(#c2245b, #f92672);
        --pix-highlighter--attr: light-dark(#6b9423, #a6e22e);
        --pix-highlighter--key: light-dark(#349fbf, #66d9ef);
        --pix-highlighter--var: light-dark(#b86e10, #fd971f);
        --pix-highlighter--mac: light-dark(#ba3fad, #fd5ff0);
        --pix-highlighter--pp: light-dark(#349fbf, #66d9ef);
        --pix-highlighter--prop: light-dark(#6b9423, #a6e22e);
        --pix-highlighter--type: light-dark(#349fbf, #66d9ef);
        --pix-highlighter--mdh: light-dark(#6b9423, #a6e22e);
        --pix-highlighter--mde: light-dark(#c2245b, #f92672);
        --pix-highlighter--mds: light-dark(#8a843f, #e6db74);
        --pix-highlighter--mdc: light-dark(#7a7866, #88846f);
        --pix-highlighter--mdl: light-dark(#349fbf, #66d9ef);
        --pix-highlighter--mdbq: light-dark(#7a7a78, #b8b8b2);
        --pix-highlighter--mdli: light-dark(#b86e10, #fd971f);
        --pix-highlighter--mdhr: light-dark(#4a4639, #5f5a4b);
        --pix-highlighter--mdimg: light-dark(#7d2ed8, #ae81ff);

        --pix-highlighter--tab-size: 2;
        --pix-highlighter--line-height: 1.55;
        --pix-highlighter--text-shadow: none;
      }
    }
  }
}
`;var oe=`/**
 * FILE: _nord.css
 * USAGE: Stylesheet for packages/pix-highlighter/src/components/PixHighlighter/styles/themes/_nord.css.
 * SCOPE: File-local selectors and pix-galaxy design tokens.
 */
@layer pix-galaxy {
  @layer pix-highlighter {
    @layer themes {
      :root[data-pix-highlighter-theme='nord'] pre[is='pix-highlighter'] {
        --pix-highlighter--bg: light-dark(#eef1f5, #2e3440);
        --pix-highlighter--fg: light-dark(#2c3039, #d8dee9);
        --pix-highlighter--kw: light-dark(#4f7aa8, #81a1c1);
        --pix-highlighter--str: light-dark(#608c4a, #a3be8c);
        --pix-highlighter--num: light-dark(#915d90, #b48ead);
        --pix-highlighter--com: light-dark(#6a758c, #616e88);
        --pix-highlighter--id: light-dark(#3b4252, #e5e9f0);
        --pix-highlighter--op: light-dark(#4099ad, #88c0d0);
        --pix-highlighter--tag: light-dark(#4f7aa8, #81a1c1);
        --pix-highlighter--attr: light-dark(#4f8a87, #8fbcbb);
        --pix-highlighter--key: light-dark(#43698b, #5e81ac);
        --pix-highlighter--var: light-dark(#aa6a47, #d08770);
        --pix-highlighter--mac: light-dark(#9b4851, #bf616a);
        --pix-highlighter--pp: light-dark(#b8974d, #ebcb8b);
        --pix-highlighter--prop: light-dark(#4099ad, #88c0d0);
        --pix-highlighter--type: light-dark(#4f8a87, #8fbcbb);
        --pix-highlighter--mdh: light-dark(#4099ad, #88c0d0);
        --pix-highlighter--mde: light-dark(#aa6a47, #d08770);
        --pix-highlighter--mds: light-dark(#b8974d, #ebcb8b);
        --pix-highlighter--mdc: light-dark(#6a758c, #616e88);
        --pix-highlighter--mdl: light-dark(#4f7aa8, #81a1c1);
        --pix-highlighter--mdbq: light-dark(#7a8495, #a7b1c2);
        --pix-highlighter--mdli: light-dark(#915d90, #b48ead);
        --pix-highlighter--mdhr: light-dark(#3b4358, #4c566a);
        --pix-highlighter--mdimg: light-dark(#4f8a87, #8fbcbb);

        --pix-highlighter--tab-size: 2;
        --pix-highlighter--line-height: 1.55;
        --pix-highlighter--text-shadow: none;
      }
    }
  }
}
`;var se=`/* ── dout compatibility shim ────────────────────────────────────────
 * Map old --dout--* tokens to new --pix--* foundations tokens.
 * Remove when all components are migrated.                          */
:root {
  --dout--border-width: 1px;
  --dout--radius-sm: var(--pix-r-sm);
  --dout--radius-md: var(--pix-r-md);
  --dout--radius-pill: var(--pix-r-pill);
  --dout--blur-panel: 0.5rem;
  --dout--z-header: 100;
  --dout--motion-fast: 160ms;
  --dout--motion-ease: ease;
  --dout--font-mono: var(--pix-t-font-mono);
  --dout--visually-hidden-size: 1px;
  --dout--visually-hidden-offset: -1px;
  --dout--lift-y: -1px;
  --dout--focus-offset: 2px;
}

@layer pix-galaxy {
  @layer pix-highlighter {
    pre[is='pix-highlighter'] {
      --pix-highlighter--toolbar-surface: color-mix(
        in srgb,
        var(--pix-highlighter--bg) 86%,
        transparent
      );
      --pix-highlighter--toolbar-border: color-mix(
        in srgb,
        var(--pix-highlighter--fg) 25%,
        transparent
      );
      --pix-highlighter--toolbar-color: var(--pix-highlighter--fg);
      --pix-highlighter--toolbar-field-bg: color-mix(
        in srgb,
        var(--pix-highlighter--fg) 8%,
        transparent
      );
      --pix-highlighter--toolbar-field-hover-bg: color-mix(
        in srgb,
        var(--pix-highlighter--fg) 14%,
        transparent
      );
      --pix-highlighter--toolbar-shadow: 0 1.125rem 2rem rgba(0, 0, 0, 0.18);
      --pix-highlighter--toolbar-menu-bg: color-mix(
        in srgb,
        var(--pix-highlighter--bg) 92%,
        transparent
      );
      --pix-highlighter--toolbar-menu-accent: color-mix(
        in srgb,
        var(--pix-highlighter--fg) 22%,
        transparent
      );
      --pix-highlighter--anchor-offset: 0.5rem;

      position: relative;
      container-type: inline-size;
      display: block;
      white-space: pre;
      word-spacing: normal;
      word-break: normal;
      word-wrap: normal;
      overflow: auto;
      tab-size: var(--pix-highlighter--tab-size);
      hyphens: none;
      padding: var(--pix-space-3) var(--pix--s--md) var(--pix--s--md);
      border: 1px solid var(--pix-highlighter--toolbar-border);
      border-radius: var(--pix-r-md);
      color: var(--pix-highlighter--fg);
      background-color: var(--pix-highlighter--bg);

      text-shadow: var(--pix-highlighter--text-shadow);

      code {
        display: block;
        color: inherit;
        background: transparent;
      }

      [data-sr-only] {
        position: absolute;
        width: var(--dout--visually-hidden-size);
        height: var(--dout--visually-hidden-size);
        padding: var(--pix--s--0);
        margin: var(--dout--visually-hidden-offset);
        overflow: hidden;
        clip: rect(0, 0, 0, 0);
        white-space: nowrap;
        border: 0;
      }

      [data-toolbar] {
        position: sticky;
        left: 0;
        top: 0;
        z-index: 1;
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: var(--pix-space-3);
        margin-block-end: 0.75rem;
        white-space: normal;
      }

      [data-theme-picker] {
        position: relative;
        margin: var(--pix--s--0);
      }

      :where([data-theme-trigger], [data-copy]) {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: var(--pix--s--sm);
        min-height: 2.5rem;
        padding: var(--pix--s--sm) var(--pix-space-3);
        border: 1px solid var(--pix-highlighter--toolbar-border);
        border-radius: var(--pix-r-md);
        background-color: var(--pix-highlighter--toolbar-surface);
        color: var(--pix-highlighter--toolbar-color);
        backdrop-filter: blur(var(--dout--blur-panel));
        cursor: pointer;
        transition:
          background-color var(--dout--motion-fast) var(--dout--motion-ease),
          border-color var(--dout--motion-fast) var(--dout--motion-ease),
          color var(--dout--motion-fast) var(--dout--motion-ease),
          transform var(--dout--motion-fast) var(--dout--motion-ease);

        svg {
          width: 1rem;
          height: 1rem;
          flex: 0 0 1rem;
        }

        &:hover:not(:disabled) {
          background-color: var(--pix-highlighter--toolbar-field-hover-bg);
          transform: translateY(calc(var(--dout--lift-y) / 2));
        }
      }

      [data-theme-trigger] {
        list-style: none;
        user-select: none;

        &::-webkit-details-marker {
          display: none;
        }

        &::marker {
          content: '';
        }
      }

      [data-theme-value] {
      }

      [data-theme-picker] {
        [data-theme-chevron] {
          display: inline-flex;
          margin-inline-start: 0.1rem;
          transition: transform var(--dout--motion-fast) var(--dout--motion-ease);
        }

        &[open] {
          [data-theme-chevron] {
            transform: rotate(180deg);
          }
        }
      }

      [data-copy] {
        width: 2.5rem;
        min-width: 2.5rem;
        padding-inline: 0;

        &[data-copy-state='copied'] {
          color: color-mix(in srgb, var(--pix-highlighter--fg) 92%, #7dffca 8%);
        }

        &[data-copy-state='error'] {
          color: color-mix(in srgb, var(--pix-highlighter--fg) 84%, #ff7f7f 16%);
        }

        &:disabled {
          cursor: not-allowed;
          opacity: 0.6;
        }
      }
    }

    /* ── Theme list (mounted on document.body, NOT inside <pre>) ── */

    [data-theme-list] {
      position: fixed;
      inset: auto;
      z-index: calc(var(--dout--z-header, 100) + 24);
      display: none;
      flex-direction: column;
      gap: var(--pix--s--xs);
      min-width: 14rem;
      max-width: min(22rem, calc(100vw - 1.5rem));
      min-height: 20rem;
      max-height: min(25rem, calc(100vh - 1.5rem));
      padding: var(--pix--s--sm);
      margin: var(--pix--s--0);
      list-style: none;
      border: 1px solid var(--pix-highlighter--toolbar-border);
      border-radius: var(--pix-r-md);
      background: var(--pix-highlighter--toolbar-menu-bg);
      box-shadow: var(--pix-highlighter--toolbar-shadow);
      backdrop-filter: blur(var(--dout--blur-panel, 1rem));
      overflow-x: hidden;
      overflow-y: auto;

      &:where([data-open='true'], :popover-open) {
        display: flex;
      }

      &::backdrop {
        background: transparent;
      }

      li {
        margin: var(--pix--s--0);
      }

      [data-theme-option] {
        display: flex;
        justify-content: space-between;
        align-items: center;
        width: 100%;
        gap: var(--pix-space-3);
        min-height: 2.25rem;
        padding: var(--pix--s--sm) var(--pix-space-3);
        border: 1px solid transparent;
        border-radius: var(--radius-sm);
        background: transparent;
        box-shadow: none;
        color: inherit;
        text-align: left;
        cursor: pointer;
        transition:
          background-color var(--dout--motion-fast) var(--dout--motion-ease),
          border-color var(--dout--motion-fast) var(--dout--motion-ease),
          color var(--dout--motion-fast) var(--dout--motion-ease);

        span:last-child {
          opacity: 0.56;
        }

        &:where(:hover, [data-selected]) {
          border-color: color-mix(in srgb, var(--pix-highlighter--fg) 40%, transparent);
          background: var(--pix-highlighter--toolbar-menu-accent);
        }
      }
    }

    @supports (anchor-name: --pix-highlighter--anchor) and
      (position-anchor: --pix-highlighter--anchor) {
      [data-theme-list][data-anchor-positioning='true'] {
        left: anchor(left);
        top: calc(anchor(bottom) + var(--pix-highlighter--anchor-offset));
        min-width: max(14rem, anchor-size(width));
        max-height: min(22rem, calc(100vh - 1.5rem));
        position-try-fallbacks: flip-block, flip-inline;
      }
    }

    @container (max-width: 16.875rem) {
      pre[is='pix-highlighter'] {
        [data-toolbar] {
          flex-direction: column;
          align-items: stretch;
        }

        [data-theme-picker] {
          width: 100%;
        }

        [data-theme-trigger] {
          width: 100%;
        }

        [data-copy] {
          width: 100%;
          min-width: 100%;
          padding-inline: 0.85rem;
        }

        [data-theme-list] {
          max-width: calc(100vw - 1.5rem);
        }
      }
    }
  }
}
`;var ae=`/* pix-foundations - entry point
 *
 * Import order: reset → helpers → foundations tokens → typography
 *
 * Usage in HTML:
 *   <link rel="stylesheet" href="/path/to/foundations.css">
 *
 * Usage in CSS:
 *   @import '@pix-galaxy/pix-foundations/foundations.css';
 *
 * Usage in JS (Vite):
 *   import '@pix-galaxy/pix-foundations/foundations.css';
 */

@layer pix.reset, pix.foundations, pix.components;

@import './_reset.css' layer(pix.reset);
/* Palettes (light/dark, WCAG 2.2 AA) are UNLAYERED so the scheme
 * custom properties always cascade to layered component CSS. */
@import './_palettes.css';
@import './_spacings.css' layer(pix.foundations.spacings);
@import './_typography.css' layer(pix.foundations.typography);
@import './_radii.css' layer(pix.foundations.radii);
@import './_controls.css' layer(pix.foundations.controls);
@import './_docs-site.css' layer(pix.foundations.docs);

/* Focus ring is intentionally UNLAYERED so it beats all component CSS.
 * WCAG 2.2 SC 2.4.7 requires the focus indicator to always be visible
 * regardless of component-specific styles - unlayered > all layered.    */
@import './_focus.css';
`;var U=Object.freeze(["kw","str","num","com","id","fn","op","tag","attr","key","var","mac","pp","prop","type","mdh","mde","mds","mdc","mdl","mdbq","mdli","mdhr","mdimg"]);function G(i){let s=(i||"").toLowerCase().trim();return new Map([["javascript","js"],["mjs","js"],["cjs","js"],["typescript","ts"],["tsx","ts"],["py","python"],["rs","rust"],["c++","cpp"],["hpp","cpp"],["h++","cpp"],["cs","csharp"],["md","markdown"],["yaml","yml"],["shell","bash"],["zsh","bash"],["scss","css"],["sass","css"]]).get(s)||s||"js"}var H=G;function u(i){return(s,r,h)=>{h>r&&i.push({type:s,start:r,end:h})}}function m(i,s,r,h={}){let e=i.length,a=s+1;for(h.includePrefix&&s--;a<e;){let n=i[a];if(n==="\\"){a+=2;continue}if(n===r){a++;break}a++}return[s,a]}function x(i,s){let r=s;if(i[r]==="-"&&r++,i.startsWith("0x",r)){for(r+=2;/[0-9a-fA-F_]/.test(i[r]);)r++;return[s,r]}if(i.startsWith("0b",r)){for(r+=2;/[01_]/.test(i[r]);)r++;return[s,r]}if(i.startsWith("0o",r)){for(r+=2;/[0-7_]/.test(i[r]);)r++;return[s,r]}for(;/[0-9_]/.test(i[r]);)r++;if(i[r]==="."&&/[0-9]/.test(i[r+1]||""))for(r++;/[0-9_]/.test(i[r]);)r++;if((i[r]||"").toLowerCase()==="e"){let h=r+1;if((i[h]==="+"||i[h]==="-")&&h++,/[0-9]/.test(i[h]||""))for(r=h+1;/[0-9_]/.test(i[r]);)r++}for(;/[a-zA-Z]/.test(i[r]||"");)r++;return[s,r]}function v(i,s){for(;/\s/.test(i[s]||"");)s++;return s}function k(i){return/[A-Za-z_$]/.test(i)}function b(i){return/[\w$-]/.test(i)}function E(i){let s=new Set(["if","then","elif","else","fi","for","in","do","done","case","esac","while","until","function","select","time","coproc"]),r=[],h=u(r),e=0,a=i.length;for(;e<a;){let n=i[e];if(e===0&&i.startsWith("#!",0)){let l=0;for(;l<a&&i[l]!==`
`;)l++;h("pp",0,l),e=l;continue}if(n==="#"){let l=e+1;for(;l<a&&i[l]!==`
`;)l++;h("com",e,l),e=l;continue}if(n==="'"||n==='"'||n==="`"){let[l,d]=m(i,e,n);h("str",l,d),e=d;continue}if(n==="$")if(i[e+1]==="{"){let l=e+2;for(;l<a&&i[l]!=="}";)l++;l=Math.min(a,l+1),h("var",e,l),e=l;continue}else{let l=e+1;for(;/[A-Za-z0-9_]/.test(i[l]||"");)l++;if(l>e+1){h("var",e,l),e=l;continue}}if(/\d|-/.test(n)){let[l,d]=x(i,e);if(d>e){h("num",l,d),e=d;continue}}if(/[A-Za-z_]/.test(n)){let l=e+1;for(;/[A-Za-z0-9_.-]/.test(i[l]||"");)l++;let d=i.slice(e,l);h(s.has(d)?"kw":"id",e,l),e=l;continue}let t=i.slice(e,e+3),o=i.slice(e,e+2);if(["<<<"].includes(t)){h("op",e,e+3),e+=3;continue}if(["&&","||",">>","<<",">|","2>",">&"].includes(o)){h("op",e,e+2),e+=2;continue}if("(){}[];:.,+-*/%&|^!~?=<>".includes(n)){h("op",e,e+1),e++;continue}e++}return r}function le(i,s){let r=new Set(["auto","break","case","char","const","continue","default","do","double","else","enum","extern","float","for","goto","if","inline","int","long","register","restrict","return","short","signed","sizeof","static","struct","switch","typedef","union","unsigned","void","volatile","while","_Bool","_Complex","_Imaginary"]);if(s)for(let t of["alignas","alignof","and","and_eq","asm","bitand","bitor","bool","catch","char8_t","char16_t","char32_t","class","compl","concept","consteval","constexpr","constinit","co_await","co_return","co_yield","decltype","delete","explicit","export","false","friend","mutable","namespace","new","noexcept","not","not_eq","operator","or","or_eq","private","protected","public","reinterpret_cast","requires","static_cast","template","this","thread_local","throw","true","try","typeid","typename","virtual","wchar_t","xor","xor_eq","using"])r.add(t);let h=[],e=u(h),a=0,n=i.length;for(;a<n;){let t=i[a];if(/\s/.test(t)){a++;continue}if(t==="#"){let o=a+1;for(;o<n&&i[o]!==`
`;)o++;e("pp",a,o),a=o;continue}if(t==="/"&&i[a+1]==="/"){let o=a+2;for(;o<n&&i[o]!==`
`;)o++;e("com",a,o),a=o;continue}if(t==="/"&&i[a+1]==="*"){let o=a+2;for(;o<n&&!(i[o]==="*"&&i[o+1]==="/");)o++;o=Math.min(n,o+2),e("com",a,o),a=o;continue}if(t==="'"){let[o,l]=m(i,a,"'");e("str",o,l),a=l;continue}if(t==='"'){let[o,l]=m(i,a,'"');e("str",o,l),a=l;continue}if(/\d|-/.test(t)){let[o,l]=x(i,a);e("num",o,l),a=l;continue}if(k(t)){let o=a+1;for(;/[A-Za-z0-9_]/.test(i[o]||"");)o++;let l=i.slice(a,o);e(r.has(l)?"kw":"id",a,o),a=o;continue}if("(){}[];:.,+-*/%&|^!~?=<>".includes(t)){e("op",a,a+1),a++;continue}a++}return h}function j(i){return le(i,!1)}function I(i){return le(i,!0)}function z(i){let s=new Set(["abstract","as","base","bool","break","byte","case","catch","char","checked","class","const","continue","decimal","default","delegate","do","double","else","enum","event","explicit","extern","false","finally","fixed","float","for","foreach","goto","if","implicit","in","int","interface","internal","is","lock","long","namespace","new","null","object","operator","out","override","params","private","protected","public","readonly","ref","return","sbyte","sealed","short","sizeof","stackalloc","static","string","struct","switch","this","throw","true","try","typeof","uint","ulong","unchecked","unsafe","ushort","using","virtual","void","volatile","while","var","dynamic","async","await","record","nint","nuint"]),r=[],h=u(r),e=0,a=i.length;for(;e<a;){let n=i[e];if(/\s/.test(n)){e++;continue}if(n==="/"&&i[e+1]==="/"){let t=e+2;for(;t<a&&i[t]!==`
`;)t++;h("com",e,t),e=t;continue}if(n==="/"&&i[e+1]==="*"){let t=e+2;for(;t<a&&!(i[t]==="*"&&i[t+1]==="/");)t++;t=Math.min(a,t+2),h("com",e,t),e=t;continue}if(n==='"'){let[t,o]=m(i,e,'"');h("str",t,o),e=o;continue}if((n==="@"||n==="$")&&i[e+1]==='"'){let[t,o]=m(i,e+1,'"',{includePrefix:!0});h("str",t,o),e=o;continue}if(/\d|-/.test(n)){let[t,o]=x(i,e);h("num",t,o),e=o;continue}if(k(n)){let t=e+1;for(;/[A-Za-z0-9_]/.test(i[t]||"");)t++;let o=i.slice(e,t);h(s.has(o)?"kw":"id",e,t),e=t;continue}if("(){}[];:.,+-*/%&|^!~?=<>".includes(n)){h("op",e,e+1),e++;continue}e++}return r}function B(i){let s=[],r=u(s),h=0,e=i.length,a=!1;for(;h<e;){let n=i[h];if(n==="/"&&i[h+1]==="*"){let t=h+2;for(;t<e&&!(i[t]==="*"&&i[t+1]==="/");)t++;t=Math.min(e,t+2),r("com",h,t),h=t;continue}if(/\s/.test(n)){h++;continue}if(n==="@"){let t=h+1;for(;b(i[t]||"");)t++;r("kw",h,t),h=t;continue}if(n==="{"){r("op",h,h+1),a=!0,h++;continue}if(n==="}"){r("op",h,h+1),a=!1,h++;continue}if(n==="'"||n==='"'){let[t,o]=m(i,h,n);r("str",t,o),h=o;continue}if(/\d|-/.test(n)){let[t,o]=x(i,h);r("num",t,o),h=o;continue}if(a){let t=h;if(k(i[t]||"")){let o=t;for(t++;b(i[t]||"");)t++;let l=t;if(t=v(i,t),i[t]===":"){r("prop",o,l),r("op",t,t+1),h=t+1;continue}r("id",o,l),h=l;continue}}else{if(n==="."||n==="#"){let t=h+1;for(;b(i[t]||"");)t++;r("id",h,t),h=t;continue}if(n===":"){let t=h+1;for(;b(i[t]||"");)t++;r("kw",h,t),h=t;continue}if(k(n)){let t=h+1;for(;b(i[t]||"");)t++;r("tag",h,t),h=t;continue}}if("()[];,:>.+*~^$|=".includes(n)){r("op",h,h+1),h++;continue}h++}return s}function R(i){let s=new Set(["break","case","chan","const","continue","default","defer","else","fallthrough","for","func","go","goto","if","import","interface","map","package","range","return","select","struct","switch","type","var"]),r=[],h=u(r),e=0,a=i.length;for(;e<a;){let n=i[e];if(/\s/.test(n)){e++;continue}if(n==="/"&&i[e+1]==="/"){let t=e+2;for(;t<a&&i[t]!==`
`;)t++;h("com",e,t),e=t;continue}if(n==="/"&&i[e+1]==="*"){let t=e+2;for(;t<a&&!(i[t]==="*"&&i[t+1]==="/");)t++;t=Math.min(a,t+2),h("com",e,t),e=t;continue}if(n==='"'){let[t,o]=m(i,e,'"');h("str",t,o),e=o;continue}if(n==="`"){let[t,o]=m(i,e,"`");h("str",t,o),e=o;continue}if(/\d|-/.test(n)){let[t,o]=x(i,e);h("num",t,o),e=o;continue}if(k(n)){let t=e+1;for(;/[A-Za-z0-9_]/.test(i[t]||"");)t++;let o=i.slice(e,t);h(s.has(o)?"kw":"id",e,t),e=t;continue}if("(){}[];:.,+-*/%&|^!~?=<>".includes(n)){h("op",e,e+1),e++;continue}e++}return r}function W(i){let s=[],r=u(s),h=0,e=i.length;for(;h<e;){if(i[h]==="<"){if(i.startsWith("<!--",h)){let o=h+4;for(;o<e&&!i.startsWith("-->",o);)o++;o=Math.min(e,o+3),r("com",h,o),h=o;continue}let n=h+1;(i[n]==="/"||i[n]==="!")&&n++;let t=n;for(;b(i[n]||"");)n++;for(n>t&&r("tag",t,n);n<e&&i[n]!==">";){if(/\s/.test(i[n])){n++;continue}if(i[n]==="/"){n++;continue}let o=n;for(;b(i[n]||"");)n++;if(n>o&&r("attr",o,n),n=v(i,n),i[n]==="=")if(r("op",n,n+1),n++,n=v(i,n),i[n]==='"'||i[n]==="'"){let l=i[n],[d,g]=m(i,n,l);r("str",d,g),n=g}else{let l=n;for(;n<e&&!/[\s>]/.test(i[n]);)n++;n>l&&r("str",l,n)}}i[n]===">"&&(r("op",n,n+1),n++),h=n;continue}h++}return s}function S(i){let s=new Set(["break","case","catch","class","const","continue","debugger","default","delete","do","else","export","extends","finally","for","function","if","import","in","instanceof","let","new","return","super","switch","this","throw","try","typeof","var","void","while","with","yield","await","of","as","from"]),r=new Set(["===","!==",">>>"]),h=new Set(["++","--","=>","==","!=","<=",">=","&&","||","??","**","<<",">>","?.","??"]),e=new Set("(){}[];:.,+-*/%&|^!~?=<>".split("")),a=[],n=u(a),t=0,o=i.length;for(;t<o;){let l=i[t];if(/\s/.test(l)){t++;continue}if(l==="/"&&t+1<o){let c=i[t+1];if(c==="/"){let p=t+2;for(;p<o&&i[p]!==`
`;)p++;n("com",t,p),t=p;continue}if(c==="*"){let p=t+2;for(;p<o&&!(i[p]==="*"&&i[p+1]==="/");)p++;p=Math.min(o,p+2),n("com",t,p),t=p;continue}}if(l==="'"||l==='"'||l==="`"){let[c,p]=m(i,t,l);n("str",c,p),t=p;continue}if(/\d|-/.test(l)){let[c,p]=x(i,t);if(p>t){n("num",c,p),t=p;continue}}if(k(l)){let c=t+1;for(;b(i[c]||"");)c++;let p=i.slice(t,c);n(s.has(p)?"kw":"id",t,c),t=c;continue}let d=i.slice(t,t+3),g=i.slice(t,t+2);if(r.has(d)){n("op",t,t+3),t+=3;continue}if(h.has(g)){n("op",t,t+2),t+=2;continue}if(e.has(l)){n("op",t,t+1),t+=1;continue}t++}return a}function q(i){let s=[],r=u(s),h=0,e=i.length,a=[];for(;h<e;){h=v(i,h);let n=i[h];if(!n)break;if(n==="{"){r("op",h,h+1),a.push(!0),h++;continue}if(n==="["){r("op",h,h+1),a.push(!1),h++;continue}if(n==="}"||n==="]"){r("op",h,h+1),a.pop(),h++;continue}if(n===","){r("op",h,h+1),h++;continue}if(n===":"){r("op",h,h+1),h++;continue}if(n==='"'){let[t,o]=m(i,h,'"'),l=v(i,o),d=a[a.length-1]===!0&&i[l]===":";r(d?"key":"str",t,o),h=o;continue}if(/\d|-/.test(n)){let[t,o]=x(i,h);r("num",t,o),h=o;continue}if(i.startsWith("true",h)||i.startsWith("false",h)||i.startsWith("null",h)){let t=i.startsWith("true",h)?"true":i.startsWith("false",h)?"false":"null";r("kw",h,h+t.length),h+=t.length;continue}h++}return s}function A(i){let s=[],r=u(s),h=i.split(`
`),e=0,a=!1,n=null;for(let o of h){let l=o.length,d=o.trim();if(/^(```|~~~)/.test(d)){r("mdc",e,e+l);let g=d[0];a?a&&g===n&&(a=!1,n=null):(a=!0,n=g),e+=l+1;continue}if(a){r("mdc",e,e+l),e+=l+1;continue}if(/^#{1,6}\s+/.test(o)){r("mdh",e,e+l),e+=l+1;continue}if(/^(\s*)([-*_]\s*){3,}$/.test(o)){r("mdhr",e,e+l),e+=l+1;continue}if(/^\s*>\s?/.test(o)){r("mdbq",e,e+l),e+=l+1;continue}if(/^\s*([-*+])\s+/.test(o)||/^\s*\d+\.\s+/.test(o)){let g=o.match(/^\s*((?:[-*+])|\d+\.)\s+/);g&&r("mdli",e+o.indexOf(g[1]),e+o.indexOf(g[1])+g[1].length)}t(o,/`([^`]+)`/g,(g,c)=>r("mdc",e+g,e+c)),t(o,/\*\*([^*]+)\*\*/g,(g,c)=>r("mds",e+g,e+c)),t(o,/__([^_]+)__/g,(g,c)=>r("mds",e+g,e+c)),t(o,/(?:^|[^*])\*([^*\n]+)\*(?!\*)/g,(g,c)=>r("mde",e+g,e+c)),t(o,/(?:^|[^_])_([^_\n]+)_(?!_)/g,(g,c)=>r("mde",e+g,e+c)),t(o,/!\[[^\]]*\]\([^)]*\)/g,(g,c)=>r("mdimg",e+g,e+c)),t(o,/\[[^\]]+\]\([^)]*\)/g,(g,c)=>r("mdl",e+g,e+c)),e+=l+1}return s;function t(o,l,d){let g;for(;g=l.exec(o);)d(g.index,g.index+g[0].length)}}function F(i){let s=new Set(["abstract","and","array","as","break","callable","case","catch","class","clone","const","continue","declare","default","do","echo","else","elseif","empty","enddeclare","endfor","endforeach","endif","endswitch","endwhile","eval","exit","extends","final","finally","for","foreach","function","global","goto","if","implements","include","include_once","instanceof","insteadof","interface","isset","list","match","namespace","new","or","print","private","protected","public","readonly","require","require_once","return","static","switch","throw","trait","try","unset","use","var","while","xor","yield","true","false","null"]),r=[],h=u(r),e=0,a=i.length;for(;e<a;){let n=i[e];if(/\s/.test(n)){e++;continue}if(n==="/"&&i[e+1]==="/"){let t=e+2;for(;t<a&&i[t]!==`
`;)t++;h("com",e,t),e=t;continue}if(n==="#"){let t=e+1;for(;t<a&&i[t]!==`
`;)t++;h("com",e,t),e=t;continue}if(n==="/"&&i[e+1]==="*"){let t=e+2;for(;t<a&&!(i[t]==="*"&&i[t+1]==="/");)t++;t=Math.min(a,t+2),h("com",e,t),e=t;continue}if(n==="'"||n==='"'){let[t,o]=m(i,e,n);h("str",t,o),e=o;continue}if(n==="$"&&k(i[e+1]||"")){let t=e+2;for(;/[A-Za-z0-9_]/.test(i[t]||"");)t++;h("var",e,t),e=t;continue}if(/\d|-/.test(n)){let[t,o]=x(i,e);h("num",t,o),e=o;continue}if(k(n)){let t=e+1;for(;/[A-Za-z0-9_]/.test(i[t]||"");)t++;let o=i.slice(e,t);h(s.has(o)?"kw":"id",e,t),e=t;continue}if("(){}[];:.,+-*/%&|^!~?=<>@".includes(n)){h("op",e,e+1),e++;continue}e++}return r}function K(i){let s=new Set(["False","None","True","and","as","assert","async","await","break","class","continue","def","del","elif","else","except","finally","for","from","global","if","import","in","is","lambda","nonlocal","not","or","pass","raise","return","try","while","with","yield"]),r=[],h=u(r),e=0,a=i.length;for(;e<a;){let n=i[e];if(/\s/.test(n)){e++;continue}if(n==="#"){let t=e+1;for(;t<a&&i[t]!==`
`;)t++;h("com",e,t),e=t;continue}if(i.startsWith("'''",e)||i.startsWith('"""',e)){let t=i[e],o=e+3;for(;o<a&&!i.startsWith(t+t+t,o);)o++;o=Math.min(a,o+3),h("str",e,o),e=o;continue}if(n==="'"||n==='"'){let[t,o]=m(i,e,n);h("str",t,o),e=o;continue}if(/\d|-/.test(n)){let[t,o]=x(i,e);h("num",t,o),e=o;continue}if(k(n)){let t=e+1;for(;/[A-Za-z0-9_]/.test(i[t]||"");)t++;let o=i.slice(e,t);h(s.has(o)?"kw":"id",e,t),e=t;continue}if("(){}[]:.,+-*/%&|^~=<>`".includes(n)){h("op",e,e+1),e++;continue}e++}return r}function $(i){let s=new Set(["as","break","const","continue","crate","else","enum","extern","false","fn","for","if","impl","in","let","loop","match","mod","move","mut","pub","ref","return","self","Self","static","struct","super","trait","true","type","unsafe","use","where","while","async","await","dyn"]),r=[],h=u(r),e=0,a=i.length;for(;e<a;){let n=i[e];if(/\s/.test(n)){e++;continue}if(n==="/"&&i[e+1]==="/"){let t=e+2;for(;t<a&&i[t]!==`
`;)t++;h("com",e,t),e=t;continue}if(n==="/"&&i[e+1]==="*"){let t=e+2;for(;t<a&&!(i[t]==="*"&&i[t+1]==="/");)t++;t=Math.min(a,t+2),h("com",e,t),e=t;continue}if(n==='"'){let[t,o]=m(i,e,'"');h("str",t,o),e=o;continue}if(n==="r"&&i[e+1]==='"'){let[t,o]=m(i,e+1,'"',{includePrefix:!0});h("str",t,o),e=o;continue}if(/\d|-/.test(n)){let[t,o]=x(i,e);h("num",t,o),e=o;continue}if(k(n)){let t=e+1;for(;/[A-Za-z0-9_]/.test(i[t]||"");)t++;if(i[t]==="!"){h("mac",e,t+1),e=t+1;continue}let o=i.slice(e,t);h(s.has(o)?"kw":"id",e,t),e=t;continue}if("(){}[]:.,+-*/%&|^!~?=<>".includes(n)){h("op",e,e+1),e++;continue}e++}return r}function D(i){let s=new Set(["interface","type","enum","implements","readonly","public","private","protected","abstract","declare","namespace","keyof","infer","satisfies","unknown","never","bigint","asserts"]),r=S(i);for(let h of r)if(h.type==="id"){let e=i.slice(h.start,h.end);s.has(e)&&(h.type="kw")}return r}function M(i){let s=[],r=u(s),h=/^(true|false|null|yes|no|on|off)$/i,e=0,a=i.length;for(;e<a;){let n=e,t=e;for(;t<a&&i[t]!==`
`;)t++;let o=i.slice(e,t);if(/^\s*(---|\.\.\.)\s*$/.test(o)){r("op",n,n+o.length),e=t+1;continue}let l=0;for(;l<o.length;){let y=o[l];if(y==="'"||y==='"'){let[T,C]=m(o,l,y);r("str",n+T,n+C),l=C;continue}if(y==="#"){r("com",n+l,n+o.length);break}l++}let d=o.match(/^(\s*)([A-Za-z0-9_.-]+)\s*:/);if(d){let y=n+d[1].length,T=y+d[2].length;r("key",y,T)}let g,c=/[&*][A-Za-z0-9_-]+/g;for(;g=c.exec(o);)r("var",n+g.index,n+g.index+g[0].length);let p=/!![^\s]+/g;for(;g=p.exec(o);)r("type",n+g.index,n+g.index+g[0].length);let ue=/[A-Za-z0-9_.-]+/g;for(;g=ue.exec(o);){let y=g[0],T=n+g.index,C=T+y.length;if(/^-?\d/.test(y)){r("num",T,C);continue}h.test(y)&&r("kw",T,C)}let X=o.match(/^(\s*)-\s+/);if(X){let y=n+X[1].length;r("op",y,y+1)}e=t+1}return s}var Oe=new Map([["js",S],["ts",D],["css",B],["json",q],["html",W],["python",K],["rust",$],["c",j],["cpp",I],["php",F],["csharp",z],["go",R],["markdown",A],["md",A],["yml",M],["yaml",M],["bash",E],["sh",E]]);function ge(i){return Oe.get(G(i))??null}var J=[ae,se,ie,re,he,te,ee,ne,oe,Q].join(`
`),He=2e3,N=8,_=12,ce="pix-highlighter-theme",je=Symbol("pixHighlighterEnhanced"),Z="data-styles",L=null,w=null;function Ie(){if(typeof globalThis.CSS?.supports!="function")return!1;try{return globalThis.CSS.supports("anchor-name: --pix-highlighter--anchor")&&globalThis.CSS.supports("position-anchor: --pix-highlighter--anchor")&&globalThis.CSS.supports("top: anchor(bottom)")}catch{return!1}}function ze(){w?.remove()}function Be(){return typeof document>"u"?null:(w||(w=document.head?.querySelector(`style[${Z}]`)||document.querySelector(`style[${Z}]`)||document.createElement("style")),w.setAttribute(Z,""),w.textContent!==J&&(w.textContent=J),w.isConnected||(document.head||document.documentElement).appendChild(w),w)}function Re(){return typeof document>"u"?null:"adoptedStyleSheets"in document&&typeof globalThis.CSSStyleSheet=="function"&&typeof globalThis.CSSStyleSheet.prototype.replaceSync=="function"?(ze(),L||(L=new CSSStyleSheet,L.replaceSync(J)),document.adoptedStyleSheets.includes(L)||document.adoptedStyleSheets.push(L),L):Be()}var Y=Object.freeze([{value:"default",label:"Default"},{value:"prism",label:"Prism"},{value:"prettylights",label:"Pretty Lights"},{value:"darcula",label:"Darcula"},{value:"cyberpunk",label:"Cyberpunk"},{value:"monokai",label:"Monokai"},{value:"nord",label:"Nord"}]),We=`
  <svg aria-hidden="true" focusable="false" viewBox="0 0 24 24"><rect width="10" height="10" x="9" y="9" fill="none" stroke="currentColor" stroke-width="1.8" rx="2" ry="2"/><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-width="1.8" d="M7 15H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h7a2 2 0 0 1 2 2v1"/></svg>
`,qe=`
  <svg aria-hidden="true" focusable="false" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 12.5 9.2 17 19 7.5"/></svg>
`,Fe=`
  <svg aria-hidden="true" focusable="false" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="1.8"/><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-width="1.8" d="M12 7.5V13"/><circle cx="12" cy="16.5" r="1" fill="currentColor"/></svg>
`,Ke=`
  <svg aria-hidden="true" focusable="false" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="1.6" d="M12 3c-5 0-9 3.6-9 8.2 0 4.4 3.6 7.8 8 7.8h1.5c.8 0 1.5.6 1.5 1.4 0 .9.7 1.6 1.6 1.6 3 0 5.4-2.7 5.4-6.2C21 8.2 17 3 12 3Z"/><circle cx="7.5" cy="11" r="1.1" fill="currentColor"/><circle cx="10.5" cy="7.5" r="1.1" fill="currentColor"/><circle cx="15" cy="7.8" r="1.1" fill="currentColor"/><circle cx="17" cy="12" r="1.1" fill="currentColor"/></svg>
`,$e=`
  <svg aria-hidden="true" focusable="false" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="m6 9 6 6 6-6"/></svg>
`;function de(){try{return window.localStorage}catch{return null}}function De(i){return Y.find(s=>s.value===i)?.label||"Default"}function Ye(i,s,r){i&&(i.innerHTML=`${s}<span data-sr-only>${r}</span>`,i.setAttribute("aria-label",r),i.title=r)}var Ve=globalThis.HTMLPreElement??class{},f=class f extends Ve{static ensureComponentStyles(){return Re()}static registerCustomElement(){let s=globalThis.customElements;if(!s?.define)return!1;if(s.get("pix-highlighter"))return!0;try{return s.define("pix-highlighter",this,{extends:"pre"}),!0}catch{return!1}}static get observedAttributes(){return["data-lang","lang"]}static supportsHighlights(){return!!(typeof window<"u"&&globalThis.CSS?.highlights&&typeof window.Highlight=="function")}static getHighlightName(s){return`pix-${s}`}static isThemeValue(s){return Y.some(r=>r.value===s)}static getSavedTheme(){let s=de()?.getItem(ce);return this.isThemeValue(s)?s:null}static getCurrentTheme(){if(typeof document>"u")return"default";let s=document.documentElement.dataset.pixHighlighterTheme;return this.isThemeValue(s)?s:"default"}static getInitialTheme(){if(typeof document>"u")return"default";let s=document.documentElement.dataset.pixHighlighterTheme;return this.isThemeValue(s)?s:this.getSavedTheme()||"default"}static ensureThemeState(){this._themeInitialized||(this._themeInitialized=!0,this.applyTheme(this.getInitialTheme(),{persist:!1,syncInstances:!1}))}static applyTheme(s,{persist:r=!0,syncInstances:h=!0}={}){let e=this.isThemeValue(s)?s:"default";if(typeof document<"u"&&(document.documentElement.dataset.pixHighlighterTheme=e),r&&de()?.setItem(ce,e),h)for(let a of this.instances)a._syncThemeControl(e);return e}static clearManagedHighlights(){if(this.supportsHighlights())for(let s of this.KNOWN_TYPES)globalThis.CSS.highlights.delete(this.getHighlightName(s))}static enhanceElement(s){return s instanceof window.HTMLPreElement?(s instanceof f||Object.setPrototypeOf(s,f.prototype),s._ensureState(),s._connect(),s):null}static enhanceAll(s=document){if(!s?.querySelectorAll)return[];let r=[];return s instanceof window.HTMLPreElement&&s.matches?.("pre[is='pix-highlighter']")&&r.push(s),r.push(...s.querySelectorAll("pre[is='pix-highlighter']")),r.map(h=>this.enhanceElement(h)).filter(Boolean)}static renderHighlights(){if(!this.supportsHighlights()){this.clearManagedHighlights();return}let s=new Map,r=new Map;for(let h of this.KNOWN_TYPES)s.set(h,new Highlight),r.set(h,0);for(let h of this.instances)if(!(!h.isConnected||!h._textNode))for(let e of h._tokens){let a=s.get(e.type);if(!a)continue;let n=document.createRange();n.setStart(h._textNode,e.start),n.setEnd(h._textNode,e.end),a.add(n),r.set(e.type,r.get(e.type)+1)}for(let h of this.KNOWN_TYPES){let e=this.getHighlightName(h);r.get(h)>0?globalThis.CSS.highlights.set(e,s.get(h)):globalThis.CSS.highlights.delete(e)}}constructor(){super(),this._ensureState()}connectedCallback(){this._connect()}_connect(){this._ensureState(),!this._isActive&&(this._isActive=!0,this.dataset.root="",this.constructor.ensureComponentStyles(),f.ensureThemeState(),f.instances.add(this),this._ensureToolbar(),this._syncThemeControl(),this._updateHighlightState({force:!0}),this._observe())}disconnectedCallback(){!this._stateReady||!this._isActive||(this._isActive=!1,this._teardownThemePicker(),this._copyButton?.removeEventListener("click",this._onCopyClick),this._themeOptionButtons?.forEach(s=>{s.removeEventListener("click",this._onThemeOptionClick)}),this._mo?.disconnect(),this._mo=null,this._textNode=null,this._tokens=[],this._themeList?.remove(),window.clearTimeout(this._copyResetTimer),this._copyResetTimer=0,f.instances.delete(this),f.renderHighlights())}attributeChangedCallback(s,r,h){this._ensureState(),(s==="data-lang"||s==="lang")&&r!==h&&this._updateHighlightState({force:!0})}_getLanguage(){return H(this.getAttribute("data-lang")||this.getAttribute("lang"))}_ensureState(){if(this._stateReady){this._supportsHighlight=f.supportsHighlights();return}this._stateReady=!0,this._id||(this._id=(++f._uid).toString(36)),this[je]=!0,this._isActive=!1,this._lastText=null,this._lastLang=null,this._tokens=[],this._textNode=null,this._mo=null,this._copyButton=null,this._themePicker=null,this._themeTrigger=null,this._themeTriggerLabel=null,this._themeList=null,this._themeOptionButtons=[],this._copyResetTimer=0,this._themeMenuListenerTimer=0,this._isSyncingCode=!1,this._supportsHighlight=f.supportsHighlights(),this._supportsAnchorPositioning=Ie(),this._supportsThemeListPopover=!1,this._onCopyClick=this._handleCopyClick.bind(this),this._onThemeOptionClick=this._handleThemeOptionClick.bind(this),this._onThemePickerToggle=this._handleThemePickerToggle.bind(this),this._onThemeListToggle=this._handleThemeListToggle.bind(this),this._onThemeMenuViewportChange=this._positionThemeList.bind(this),this._onThemeMenuClick=this._handleDocumentClick.bind(this),this._onThemeMenuKeyDown=this._handleDocumentKeyDown.bind(this)}_getCodeElement(){return this.querySelector("code")}_ensureToolbar(){let s=this.querySelector("[data-toolbar]");if(s){this._themePicker=s.querySelector("[data-theme-picker]"),this._themeTrigger=s.querySelector("[data-theme-trigger]"),this._themeTriggerLabel=s.querySelector("[data-theme-value]"),this._themeList=s.querySelector("[data-theme-list]"),this._themeList||(this._themeList=document.getElementById(this._themeTrigger?.getAttribute("aria-controls")||"")),this._copyButton=s.querySelector("[data-copy]"),this._themeOptionButtons=Array.from((this._themeList||s).querySelectorAll("[data-theme-option]")),this._teardownThemePicker(),this._copyButton?.removeEventListener("click",this._onCopyClick),this._themeOptionButtons.forEach(g=>{g.removeEventListener("click",this._onThemeOptionClick)}),this._copyButton?.addEventListener("click",this._onCopyClick),this._themeOptionButtons.forEach(g=>{g.addEventListener("click",this._onThemeOptionClick)}),this._bindThemePicker();return}let r=document.createElement("span");r.dataset.toolbar="",r.setAttribute("role","group"),r.setAttribute("aria-label","Code block actions");let h=document.createElement("details");h.dataset.themePicker="";let e=document.createElement("summary");e.dataset.themeTrigger="",e.setAttribute("aria-label","Syntax highlight theme");let a=document.createElement("span");a.dataset.themeValue="";let n=document.createElement("span");n.dataset.themeIcon="",n.innerHTML=Ke;let t=document.createElement("span");t.dataset.themeChevron="",t.innerHTML=$e,e.append(n,a,t);let o=document.createElement("ul");o.dataset.themeList="",o.id=`pix-highlighter-theme-list-${this._id}`,o.setAttribute("role","listbox"),o.setAttribute("aria-label","Syntax highlight themes"),e.setAttribute("aria-haspopup","listbox"),e.setAttribute("aria-controls",o.id),e.setAttribute("aria-expanded","false");let l=[];for(let g of Y){let c=document.createElement("li"),p=document.createElement("button");p.type="button",p.dataset.themeOption=g.value,p.setAttribute("role","option"),p.innerHTML=`<span>${g.label}</span><span aria-hidden="true">${g.value}</span>`,c.appendChild(p),o.appendChild(c),l.push(p)}h.append(e,o);let d=document.createElement("button");d.type="button",d.dataset.copy="",this._setCopyButtonState("idle",d),r.append(h,d),this.prepend(r),this._themePicker=h,this._themeTrigger=e,this._themeTriggerLabel=a,this._themeList=o,this._themeOptionButtons=l,this._copyButton=d,this._copyButton.addEventListener("click",this._onCopyClick),this._themeOptionButtons.forEach(g=>{g.addEventListener("click",this._onThemeOptionClick)}),this._bindThemePicker()}_bindThemePicker(){this._themePicker&&(this._mountThemeList(),this._configureThemeAnchor(),this._themePicker.removeEventListener("toggle",this._onThemePickerToggle),this._themePicker.addEventListener("toggle",this._onThemePickerToggle),this._themeTrigger&&this._themeList&&(this._themeList.id||(this._themeList.id=`pix-highlighter-theme-list-${this._id}`),this._themeTrigger.setAttribute("aria-haspopup","listbox"),this._themeTrigger.setAttribute("aria-controls",this._themeList.id),this._themeTrigger.setAttribute("aria-expanded",String(!!this._themePicker.open))))}_mountThemeList(){!this._themeList||typeof document>"u"||(this._themeList.parentElement!==document.body&&document.body.append(this._themeList),this._supportsThemeListPopover=typeof this._themeList.showPopover=="function"&&typeof this._themeList.hidePopover=="function",this._supportsThemeListPopover?(this._themeList.setAttribute("popover","auto"),this._themeList.removeEventListener("toggle",this._onThemeListToggle),this._themeList.addEventListener("toggle",this._onThemeListToggle)):(this._themeList.removeEventListener("toggle",this._onThemeListToggle),this._themeList.removeAttribute("popover")))}_syncThemeListSurface(){if(!this._themeList||typeof window>"u")return;let s=window.getComputedStyle(this);["--pix-highlighter--bg","--pix-highlighter--fg","--pix-highlighter--toolbar-border","--pix-highlighter--toolbar-color","--pix-highlighter--toolbar-menu-accent","--pix-highlighter--toolbar-menu-bg","--pix-highlighter--toolbar-shadow"].forEach(h=>{let e=s.getPropertyValue(h).trim();e&&this._themeList.style.setProperty(h,e)})}_getThemeAnchorName(){return`--pix-highlighter--highlighter-theme-trigger-${this._id}`}_configureThemeAnchor(){if(!this._themeTrigger||!this._themeList)return;let s=this._getThemeAnchorName();this._themeTrigger.style.setProperty("anchor-name",s),this._themeList.style.setProperty("position-anchor",s),this._themeList.style.setProperty("--pix-highlighter--anchor-offset",`${N}px`),this._themeList.dataset.anchorPositioning=String(this._supportsAnchorPositioning)}_teardownThemePicker(){this._themePicker?.removeEventListener("toggle",this._onThemePickerToggle),this._themeList?.removeEventListener("toggle",this._onThemeListToggle),window.clearTimeout(this._themeMenuListenerTimer),this._themeMenuListenerTimer=0,this._removeFloatingThemePickerListeners(),this._hideThemeListPopover(),this._resetThemeListPosition(),this._themeTrigger&&this._themeTrigger.setAttribute("aria-expanded","false")}_addFloatingThemePickerListeners(){typeof window>"u"||typeof document>"u"||(window.addEventListener("resize",this._onThemeMenuViewportChange),document.addEventListener("scroll",this._onThemeMenuViewportChange,!0),document.addEventListener("click",this._onThemeMenuClick,!0),document.addEventListener("keydown",this._onThemeMenuKeyDown,!0))}_removeFloatingThemePickerListeners(){typeof window>"u"||typeof document>"u"||(window.removeEventListener("resize",this._onThemeMenuViewportChange),document.removeEventListener("scroll",this._onThemeMenuViewportChange,!0),document.removeEventListener("click",this._onThemeMenuClick,!0),document.removeEventListener("keydown",this._onThemeMenuKeyDown,!0))}_resetThemeListPosition(){this._themeList&&(this._themeList.style.removeProperty("position"),this._themeList.style.removeProperty("inset"),this._themeList.style.removeProperty("top"),this._themeList.style.removeProperty("left"),this._themeList.style.removeProperty("min-width"),this._themeList.style.removeProperty("height"),this._themeList.style.removeProperty("max-height"),this._themeList.style.removeProperty("display"),this._themeList.style.removeProperty("visibility"),this._themeList.removeAttribute("data-open"))}_hideThemeListPopover(){if(!(!this._supportsThemeListPopover||!this._themeList?.matches(":popover-open")))try{this._themeList.hidePopover()}catch{}}_scheduleThemeListPosition(){if(typeof window<"u"&&typeof window.requestAnimationFrame=="function"){window.requestAnimationFrame(()=>{this._positionThemeList()});return}this._positionThemeList()}_handleThemePickerToggle(){let s=!!this._themePicker?.open;if(this._themeTrigger&&this._themeTrigger.setAttribute("aria-expanded",String(s)),!s){window.clearTimeout(this._themeMenuListenerTimer),this._themeMenuListenerTimer=0,this._removeFloatingThemePickerListeners(),this._hideThemeListPopover(),this._resetThemeListPosition();return}if(window.clearTimeout(this._themeMenuListenerTimer),this._themeList?.setAttribute("data-open","true"),this._syncThemeListSurface(),this._supportsThemeListPopover&&!this._themeList.matches(":popover-open"))try{this._themeList.showPopover()}catch{}this._scheduleThemeListPosition(),this._themeMenuListenerTimer=window.setTimeout(()=>{this._themeMenuListenerTimer=0,this._themePicker?.open&&this._addFloatingThemePickerListeners()},0)}_handleThemeListToggle(){!this._supportsThemeListPopover||this._themeList?.matches(":popover-open")||(this._themePicker?.open&&(this._themePicker.open=!1),this._themeTrigger?.setAttribute("aria-expanded","false"),this._removeFloatingThemePickerListeners(),this._resetThemeListPosition())}_handleDocumentClick(s){if(!this._themePicker?.open)return;let r=s.target;r instanceof Node&&(this._themePicker.contains(r)||this._themeList?.contains(r))||(this._themePicker.open=!1)}_handleDocumentKeyDown(s){s.key!=="Escape"||!this._themePicker?.open||(this._themePicker.open=!1,this._hideThemeListPopover(),this._themeTrigger?.focus())}_positionThemeList(){if(typeof window>"u"||!this._themePicker?.open||!this._themeTrigger||!this._themeList)return;let s=this._themeTrigger.getBoundingClientRect(),r=Math.max(s.width,224);if(this._syncThemeListSurface(),this._supportsAnchorPositioning){this._themeList.style.removeProperty("position"),this._themeList.style.removeProperty("inset"),this._themeList.style.removeProperty("left"),this._themeList.style.removeProperty("top"),this._themeList.style.minWidth=`${Math.round(r)}px`,this._themeList.style.maxHeight=`${Math.max(120,window.innerHeight-_*2)}px`;return}this._themeList.style.position="fixed",this._themeList.style.inset="auto",this._themeList.style.display="flex",this._themeList.style.visibility="",this._themeList.style.left="-9999px",this._themeList.style.top="-9999px",this._themeList.style.minWidth=`${Math.round(r)}px`,this._themeList.style.maxHeight=`${Math.max(120,window.innerHeight-_*2)}px`;let h=this._themeList.getBoundingClientRect(),e=Math.min(Math.max(r,h.width||this._themeList.offsetWidth||r),window.innerWidth-_*2),a=h.height||this._themeList.scrollHeight||0,n=window.innerHeight-s.bottom-_-N,t=s.top-_-N,o=n<Math.min(a,240)&&t>n,l=Math.max(120,o?t:n),d=Math.min(a||l,l),g=s.left;g+e>window.innerWidth-_&&(g=window.innerWidth-_-e),g=Math.max(_,g);let c=o?Math.max(_,s.top-N-d):Math.max(_,Math.min(s.bottom+N,window.innerHeight-_-d));this._themeList.style.left=`${Math.round(g)}px`,this._themeList.style.top=`${Math.round(c)}px`,this._themeList.style.minWidth=`${Math.round(e)}px`,this._themeList.style.maxHeight=`${Math.round(l)}px`}_observe(){this._mo?.disconnect(),this._mo=new MutationObserver(s=>{if(this._isSyncingCode)return;let r=s.some(h=>h.type==="attributes"&&(h.attributeName==="data-lang"||h.attributeName==="lang"));this._updateHighlightState({force:r})}),this._mo.observe(this,{attributes:!0,attributeFilter:["data-lang","lang"],childList:!0,characterData:!0,subtree:!0})}_updateHighlightState({force:s=!1}={}){let r=this._getCodeElement();if(!r){this._tokens=[],this._textNode=null,f.renderHighlights();return}let h=r.textContent??"",e=this._getLanguage();!s&&h===this._lastText&&e===this._lastLang||(this._lastText=h,this._lastLang=e,this._tokens=this._lex(e,h),this._supportsHighlight?(this._isSyncingCode=!0,r.textContent=h,this._textNode=r.firstChild||r.appendChild(document.createTextNode("")),this._isSyncingCode=!1):(this._textNode=null,this._renderFallbackMarkup(r,h,this._tokens)),f.renderHighlights())}_renderFallbackMarkup(s,r,h){if(this._isSyncingCode=!0,!h.length){s.textContent=r,this._isSyncingCode=!1;return}let e=document.createDocumentFragment(),a=0;for(let n of h){if(n.start<a)continue;n.start>a&&e.append(document.createTextNode(r.slice(a,n.start)));let t=document.createElement("span");t.dataset.token=n.type,t.textContent=r.slice(n.start,n.end),e.append(t),a=n.end}a<r.length&&e.append(document.createTextNode(r.slice(a))),s.replaceChildren(e),this._isSyncingCode=!1}_syncThemeControl(s=f.getCurrentTheme()){this._themeTriggerLabel&&(this._themeTriggerLabel.textContent=De(s)),this._themeOptionButtons.forEach(r=>{let h=r.dataset.themeOption===s;r.toggleAttribute("data-selected",h),r.setAttribute("aria-selected",String(h))})}_handleThemeOptionClick(s){let r=s.currentTarget.dataset.themeOption;f.applyTheme(r),this._themePicker&&(this._themePicker.open=!1),this._hideThemeListPopover(),this._resetThemeListPosition()}async _handleCopyClick(){let s=this._getCodeElement();if(s?.textContent)try{await this._copyText(s.textContent),this._setCopyButtonState("copied")}catch{this._setCopyButtonState("error")}}async _copyText(s){if(window.navigator?.clipboard?.writeText){await window.navigator.clipboard.writeText(s);return}let r=document.createElement("textarea");r.value=s,r.setAttribute("readonly",""),r.style.position="fixed",r.style.opacity="0",document.body.appendChild(r),r.select();let h=document.execCommand?.("copy");if(r.remove(),!h)throw new Error("Copy command failed")}_setCopyButtonState(s,r=this._copyButton){if(!r)return;let h={idle:{icon:We,label:"Copy code"},copied:{icon:qe,label:"Code copied"},error:{icon:Fe,label:"Copy failed"}},e=h[s]||h.idle;r.dataset.copyState=s,Ye(r,e.icon,e.label),r===this._copyButton&&(window.clearTimeout(this._copyResetTimer),this._copyResetTimer=window.setTimeout(()=>{this._setCopyButtonState("idle")},He))}_lex(s,r){let h=ge(s);return h?h(r):[]}};P(f,"_uid",0),P(f,"instances",new Set),P(f,"KNOWN_TYPES",U),P(f,"_themeInitialized",!1),f.ensureComponentStyles(),f.registerCustomElement(),typeof document<"u"&&(document.readyState==="loading"?document.addEventListener("DOMContentLoaded",pe,{once:!0}):queueMicrotask(pe));var V=f;function me(i=document){return V.enhanceAll(i)}function pe(){typeof document>"u"||me(document)}
